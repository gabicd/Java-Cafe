package javacafe.controllers;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class salesController extends PageNavigationController {
    public void initialize(URL location, ResourceBundle resources) {
        // This method is called by the FXMLLoader when initialization is complete
        System.out.println("Order Page Initialized");
    }

    public void goToOrder(ActionEvent event) throws IOException {super.goToOrder(event);}

    public void goToItems(ActionEvent event) throws IOException { super.goToItems(event); }

    public void goToInventory(ActionEvent event) throws IOException {super.goToInventory(event);}
    @Override
    public void goToSales(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("You already are on the sales screen!");
        alert.showAndWait();

    }

    public void exitScreen(ActionEvent event) throws IOException {super.exitScreen(event);}

    public void generateReport (ActionEvent event) throws IOException{

    }
}
